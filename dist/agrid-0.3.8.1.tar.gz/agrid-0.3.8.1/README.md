# agrid
v.0.4.8

_Tobias Stål, 2020_
---

---

agrid is package for processing, containing, visualise and export multidimensional and multivariate data. It also contains functionality for probabilistic methods. 

---

To get started:

​    from agrid import Grid

​    world = Grid()

​    # The grid is already populated with default coordinates

​     print(world.ds) 

Further tutorials are available at [GitHub](https://github.com/TobbeTripitaka/agrid/tree/master/tutorials) 



---

Software paper availible here: [JORS](https://openresearchsoftware.metajnl.com/articles/10.5334/jors.287/)

If used for publication, please cite:

​    @article{Staal2020a,
​    abstract = {Researchers use 2D and 3D spatial models of multivariate data of differing resolutions and formats. It can be challenging to work with multiple datasets, and it is time consuming to set up a robust, performant grid to handle such spatial models. We share 'agrid', a Python module which provides a framework for containing multidimensional data and functionality to work with those data. The module provides methods for defining the grid, data import, visualisation, processing capability and export. To facilitate reproducibility, the grid can point to original data sources and provides support for structured metadata. The module is written in an intelligible high level programming language, and uses well documented libraries as numpy, xarray, dask and rasterio.},
​    author = {St{\aa}l, Tobias and Reading, Anya M.},
​    doi = {10.5334/JORS.287},
​    issn = {20499647},
​    journal = {Journal of Open Research Software},
​    keywords = {Multivariate processing, Python, Regular grid, Spatial model},
​    month = {jan},
​    number = {1},
​    pages = {1--10},
​    publisher = {Ubiquity Press, Ltd.},
​    title = {{A grid for multidimensional and multivariate spatial representation and data processing}},
​    volume = {8},
​    year = {2020}
​    }